Supplementary File S5 evidence bundle

This archive contains the selected records used for the document-driven
virtual-line acceptance, deterministic protocol checks, and four scripted
simulator missions summarized in Supplementary File S5. The records
are separate evidence units and are not pooled as repeated trials. All process
observations are from local simulations; no physical-plant data are included.

The local temporary path in the export-statistics record is redacted. The file
manifest lists delivered paths, sizes, and SHA-256 hashes, together with the
source hash for the transformed record.
