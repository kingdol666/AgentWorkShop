# S7 November 5 Follow-up Evidence (r1)

This package preserves the original November 5 follow-up records and adds the three artifacts named by the original run checksum list but missing from the first follow-up archive: the environment preflight record and two Agent logs. The original run-generated checksum file is retained as an execution artifact; the root `manifest.json` hashes every file in this package except the manifest itself.

## Evidence scope

- Four-scene recipe-window probes: selected simulator requests returned 110/110 expected window rejections. The input values and check limits derive from the same configuration; this does not validate engineering correctness or a population rejection rate.
- One simulated readback-mismatch injection: command 230, driver readback 251, tolerance 0.7, acknowledgement `unverified`; a separate read of the same simulator also returned 251. `readback-mismatch/INTERPRETATION-ERRATUM.md` clarifies the original report's delta terminology. This is not independent hardware or a retry study.
- Two live-Agent attempts: canceled, zero rounds and zero governed writes; the logs do not establish the cancellation cause. The aggregate pipeline status is not passing.
- The preflight's model check lists available models; it does not run an inference completion. Its governed write is scripted, not an Agent task.

The platform and simulator were already running. Recorded source hashes and commits identify the runner and its libraries but do not prove the versions deployed in those services. This package is not pooled with the frozen November 1 results and does not establish physical-plant performance or autonomous-Agent efficacy.