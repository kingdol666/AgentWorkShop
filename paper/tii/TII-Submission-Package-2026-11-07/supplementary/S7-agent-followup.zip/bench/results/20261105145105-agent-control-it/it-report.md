# Agent 控制集成测试 · 20261105145105-agent-control-it

- 判定:**PASS** 
- base=http://127.0.0.1:3578 sim=http://127.0.0.1:4012 AW_HOME=D:\tmp\aw-agent-it-20261105 commit=c0c9b41b dirty=329
- omp 模型: `qwen3.5-9b-claude-4.6-opus-reasoning-distilled-v2` / provider `lm-studio`

- ✔ **S0a-env-isolation** AW_HOME=D:\tmp\aw-agent-it-20261105 BENCH_MODE=1 BENCH_ACK=1 SIM_BASE=http://127.0.0.1:4012
- ✔ **S0b-platform** up@http://127.0.0.1:3578
- ✔ **S0c-simulator** http://127.0.0.1:4012
- ✔ **S0d-single-listener** port=3578 listeners=1 pids=78520
- ✔ **S0e-auth** admin login ok
- ✔ **S0f-settings** stall=900000 hitl=900000 root=3600000(要求 ≥9min/9min/60min)
- ✔ **S1a-provision** line=ln-87cd15d7 dcw=11 daq=14 started
- ✔ **S1b-daq-live** PV 节点 dn-df533bf5 60s 内采到 ≥5 样本(时序活)
- ✔ **S2-governed-write** node=dw-322d14d1(hold-pressure-sp) 写 56 → status=200 ack=readback-verified 节点值=56 容差=0.45
- ✔ **S3a-channel** legacy 频道 d7690a6f 创建(recipe_trial 写链)
- ✔ **S3a-bind** 绑定 25 条(dcw PATCH confirm auto)
- ✔ **S3b-token** worker token 已取(rotate 一次性)
- ✔ **S3c-line-status** line_status → 产线状态: · 注塑成型质量窗口寻优 injection-ity3nr:运行中(批次 rr-944f9,配方「scen-injection-recipe-ity3nr」,产品「scen-injection-product-ity3nr」,自
- ✔ **S3d-daq-query** daq_query(dn-df533bf5) → 有数据返回
- ✔ **S3e-my-nodes** my_industrial_nodes → 列出绑定节点
- ✔ **S3f-recipe-trial-write** worker 身份 recipe_trial 写 hold-pressure-sp=58(HITL 代理已批) → 试验已整批下发并全部设备证实(1/1,批次 rr-227c3):scen-injection:dcw:hold-pressure-sp→58bar [证实✓]。假设:集成门写探针:hold-press
- ✔ **S3-face-gate** worker 工具面四探全过(读面可见 + recipe_trial 受治理写真实通过)
