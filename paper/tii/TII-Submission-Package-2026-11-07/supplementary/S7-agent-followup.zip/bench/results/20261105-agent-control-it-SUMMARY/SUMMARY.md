# 数采/数控/Agent 控制集成测试 · 总汇整（2026-11-05 晚间轮）

**环境**：全新隔离实例 `AW_HOME=D:\tmp\aw-agent-it-20261105`，平台 `:3578`（单监听断言通过），
影子模拟器 `:4012`，双 bench env（AW_BENCH_MODE=1 + AW_BENCH_ACK=1），设置 stall/hitl=9min、root=60min。
模型：qwen3.5-9b-claude-4.6-opus（32k/parallel=1）×4 episodes + zai-org/glm-4.7-flash（30B，32k）×1 episode。

---

## 1. 结论（对应用户三问）

**① 新环境启动** ✔ —— 全新隔离根自举，7/7 环境门（隔离块/平台/模拟器/单监听/鉴权/设置/模型）全过。

**② 数采数控集成** ✔ —— S1 数采活（PV 节点 60s 内 ≥5 实时样本，时间戳+数值）；
S2 数控治理写 `readback-verified` + 节点值=写入值(±0.45 容差)。run：`20261105145105-agent-control-it`（终版 PASS）。

**③ Agent 能否真正操控产线** —— **分两层回答**：

- **确定性工具面层：能（已证明）**。S3f 探针：以 worker token（与 omp worker set_host_tools 同源）调
  `recipe_trial` → HITL 卡签发 → runner 代理批准（治理链"人"腿，bench 语义）→ 整批试验下发 →
  **设备侧证实 1/1**（`hold-pressure-sp→58bar [证实✓]`）。绑定收窄+配方窗+审批链全程生效。
  run：`20261105145105-agent-control-it` S3f PASS。
- **LLM 自主闭环层：阴性（本轮 5 episodes，0 次 agent 发起的受治理写入）**。但本轮把此前
  "0 写入"的**五层根因全部定位并逐层修复/绕过**，最终收敛到唯一剩余层：本地模型能力（见 §3）。

## 2. 本轮修复（全部已入 bench 代码，受益后续所有 run）

| # | 缺陷 | 修复 |
|---|---|---|
| 1 | worker 拿节点「名称」当 node_id → 授权面必拒（audit 实证） | optloop 任务书注入 sig→运行时 id 全量清单 + 读数捷径（node_ids 批量） |
| 2 | dcw 绑定只 POST 未 PATCH confirm → 全部停在 manual | 绑定三步：POST → PATCH confirm auto → 失败熔断（api.call 不抛 HTTP 错的静默吞掉也熔断） |
| 3 | 改派不生效静默（lead 零绑定接手=空跑） | 改派状态显式判：200 才算改派成功 |
| 4 | provision 复用不重置 SP → 上轮写入残响污染下轮初态 | `provisionScenarioLine(..., {fresh:true})`（episode 隔离语义，缺省行为不变） |
| 5 | 录制器 tap 第一个终端 = lead，worker 回合不可见 | recorder 按 workerInst 精确 tap |
| 6 | 任务书指名 `dcw_control` —— **该工具从未进 host-tools.json（108 声明源），任何 agent 会话都挂载不到** | 写入指令改 `recipe_trial`（唯一活的受治理 agent 写链） |
| 7 | recipe_trial 恒 HITL 卡，无人批 → invoke 悬挂 | runner 人工代理：轮询 pending 卡 → decide approved（每笔留痕 auto-approvals.jsonl） |
| 8 | optloop 退出码被管道 tail 掩蔽 | 退出码落盘 exit-code.txt |

## 3. 五层根因递进（0 写入的完整解释链）

1. **名称≠id**（ep 前轮，audit `tool.call.denied` 直证）→ 已修（节点清单）。
2. **绑定 manual+静默失败**（store 25 条全 manual；api.call 吞 404）→ 已修（confirm+熔断）。
3. **工具面不可见疑云**（104454 line_status「未绑定」而绑定在册）→ 新环境未复现（支持双进程陈旧内存假设）；
   本轮以 S3 三探 + 单监听断言常态化防护。
4. **`dcw_control`/`param_control` 不存在于 host-tools.json** —— hybrid_twin+bounded_auto 的写族在
   dispatch 被恒拒 `AML_TWIN_WRITE_GRANT_REQUIRED`，而 **WriteGrant 签发机制代码中不存在**
   （catalog 与 dispatch 双层矛盾，hybrid 在线写当前不可达）→ 绕过（recipe_trial 链）。
   **平台缺口 G-2 记法入册**（G-1=goal 判据旁路：带外收口仍 COMPLETED，无 judge 证据强制）。
5. **本地模型能力**（本轮终局）——
   ep3：13 次真实 daq_query（id 全对、数据全真）但单节点逐查烧完回合，未到写入，lead 代收口；
   ep4：1 次批量读后 reasoning 退化循环（`read`×87，重复句无限循环）；
   ep5（30B）：**零工具调用**，推理过长触发 stall watchdog CANCELED。

## 4. Episode 分母（本轮 5 个，全部隔离有效，全部如实入册）

| episode | 模型 | 工具调用 | 收口 | PV(带外) | 判定 |
|---|---|---|---|---|---|
| 1kjc | 9B | 1 | COMPLETED | 31.93 | NO_WRITE |
| 1ers | 9B | 2 (xd:// 误用→臆造) | COMPLETED | 31.92 | NO_WRITE |
| tqs | 9B | 13（真实读，id 全对） | COMPLETED | 32.04 | NO_WRITE |
| 1lkc | 9B | 93（退化循环） | COMPLETED | — | NO_WRITE |
| ul0 | 30B | 0 | CANCELED(stall) | 32.03 | NO_WRITE |

G-1 再实证：ep3/ep4 带外收口 COMPLETED（无 judge 证据、无交付达标），分母口径与 EXPERIMENT-PIPELINE §5 一致。

## 5. 产物清单（本目录 manifest.json + SHA256SUMS.txt）

- 集成门 7 runs：`20261105140947/141249/142118/143752/144503/144612/145105-agent-control-it`（终版=145105，S3f PASS）
- Episodes 5 runs（各含 chain-evidence/、optloop 四录、console/exit-code）：`20261105141314-1kjc / 142147-1ers / 145202-tqs / 150434-1lkc / 152544-ul0-optloop`
- 收集器：`bench/tools/collect-agent-chain-evidence.mjs`（七环判定：任务→工具调用→治理→审批→回执→回读→写后数采）

## 6. 下一轮入口

1. **阳性 LLM episode 的最后一块拼图 = 更强模型**：本地 30B 已证不可用（stall）；需远程 API（ustc 不可达，
   无官方 key）或载入更强开源模型（如 Qwen3.5-27B，VRAM 待核）。env/流程已全部就绪，换模型即跑。
2. **平台修复两项**（行为变更，需批准）：G-1 goal 判据在改派路径强制（complete 需 judge 证据）；
   G-2 WriteGrant 签发实现（否则 hybrid 在线写永远是死路）。
3. recipe_trial 阳性链已通（S3f），P0 论文口径可更新为："agent-identity governed write verified end-to-end
   (deterministic probe)；LLM-autonomous episodes remain negative (5 runs, taxonomy in S7)"。
