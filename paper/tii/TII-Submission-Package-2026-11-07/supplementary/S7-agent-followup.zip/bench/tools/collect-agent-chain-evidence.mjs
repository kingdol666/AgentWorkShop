#!/usr/bin/env node
/**
 * bench/tools/collect-agent-chain-evidence.mjs —— live-Agent episode 链式证据收集与判定
 *
 * 用途:optloop episode(或 agent-control-it)结束后,把「一次受治理写入」的七环证据
 *   (任务上下文 → Agent 工具调用 → 治理判定 → HITL 审批 → 驱动回执 → 回读 → dispatch 后
 *   数采观测)从各系统侧存储按写事件关联成 chain-evidence.json,并给出诚实判定:
 *   chain_complete / chain_incomplete(缺环如实标)。
 *
 * 数据源(全部只读):
 *   <AW_HOME>/data/workshop.sqlite   tasks(任务/收口)/ messages(派发链)/ approval_requests
 *                                    audit_log(tool.call.denied 等审计)/ channel_agents(身份)
 *   <AW_HOME>/data/dcw-writes.json   写控台账(at/nodeId/ack/taskId/approvalId)
 *   <runDir>/injection-worker-stream.jsonl  worker 终端全帧(toolcall/文本)
 *   <runDir>/injection-quality.jsonl        本线数采曲线(写后 PV 响应)
 *   <runDir>/auto-approvals.jsonl           runner 代理审批留痕
 *   <runDir>/summary.json                   optloop 独立终验(PV/守卫)
 *
 * 用法:node bench/tools/collect-agent-chain-evidence.mjs --run <runDir> [--out <dir>]
 * 判定纪律:七环任一缺失 → 该写事件 chain_incomplete;只有「非脚本 actor 的受治理写 +
 * 七环齐」才可称 live-Agent 完整链。阴性 episode 同样全量收集(失败分类学输入)。
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { join, resolve, basename } from 'node:path'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'

const HERE = dirname(fileURLToPath(import.meta.url))
const REPO = resolve(HERE, '..', '..')
const args = process.argv.slice(2)
const arg = (k, d) => { const i = args.indexOf(`--${k}`); return i >= 0 ? (args[i + 1] ?? '') : d }

const runDir = resolve(arg('run'))
if (!existsSync(runDir)) { console.error(`✘ run 目录不存在: ${runDir}`); process.exit(1) }
const awHome = process.env.AW_HOME ?? resolve(REPO, '.AgentWorkShop')
const dbPath = join(awHome, 'data', 'workshop.sqlite')
const writesPath = join(awHome, 'data', 'dcw-writes.json')

// ── run 目录输入 ──
const label = (['injection', 'wwtp', 'anneal', 'biax'].find(l => existsSync(join(runDir, `${l}-summary.json`)) || existsSync(join(runDir, `${l}-quality.jsonl`)))) ?? 'injection'
const summary = existsSync(join(runDir, 'summary.json')) ? JSON.parse(readFileSync(join(runDir, 'summary.json'), 'utf8')) : null
const line0 = summary?.lines?.[0] ?? null
const epStart = line0 ? new Date(Date.parse(summary.at ?? Date.now()) - 60_000).toISOString() : null
const epEnd = new Date().toISOString()

// worker-stream:抽取 toolcall 序列与收口文本
const wsFrames = []
const wsPath = join(runDir, `${label}-worker-stream.jsonl`)
if (existsSync(wsPath)) {
  for (const line of readFileSync(wsPath, 'utf8').split('\n')) {
    if (!line.trim()) continue
    try { const j = JSON.parse(line); if (j.type === 'term.frames') wsFrames.push(...(j.frames ?? [])) } catch { }
  }
}
const toolcalls = []
for (const f of wsFrames) {
  const ff = f.get ? f : f.frame ?? f
  if (ff?.type !== 'message_update') continue
  const ev = ff.assistantMessageEvent ?? {}
  if (ev.type !== 'toolcall_start') continue
  const c = (ev.partial?.content ?? []).find(x => x.type === 'toolCall' || x.toolName)
  if (c) toolcalls.push({ name: c.toolName ?? c.name, args: typeof c.arguments === 'string' ? c.arguments.slice(0, 300) : JSON.stringify(c.arguments ?? c.input ?? {}).slice(0, 300) })
}
const wsTexts = []
for (const f of wsFrames) {
  const ff = f.get ? f : f.frame ?? f
  if (ff?.type === 'message_end' && ff.text && ff.text.length > 8) wsTexts.push(ff.text.slice(0, 200))
}

// ── 平台侧输入 ──
let db = null
const q = (sql, p = []) => { try { return db.prepare(sql).all(...p) } catch (e) { return [] } }
try { const { default: Database } = await import('node:sqlite'); db = new Database(dbPath, { readOnly: true }) } catch { /* sqlite 不可用时降级 */ }

const writes = existsSync(writesPath) ? JSON.parse(readFileSync(writesPath, 'utf8')) : []
const writeRows = (Array.isArray(writes) ? writes : writes.writes ?? [])
  .filter(w => epStart ? String(w.at) >= epStart : true)
  .filter(w => w.nodeId && (w.ack ?? w.ackSummary))

// 线上节点(区分脚本基线 vs agent 写:台账 taskId/approvalId/actor 语义)
const lineNodes = new Set(line0 ? [...Object.values(line0.dcw ?? {}), ...Object.values(line0.daq ?? {})] : [])
const epWrites = writeRows.filter(w => lineNodes.has(w.nodeId))
const agentWrites = epWrites.filter(w => w.taskId || w.approvalId)

// HITL 卡与 runner 代理决策
const autoApprovals = existsSync(join(runDir, 'auto-approvals.jsonl'))
  ? readFileSync(join(runDir, 'auto-approvals.jsonl'), 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  : []
const hitlCards = q(`SELECT id,status,kind,title,created_at AS at FROM hitl_requests WHERE created_at >= ? ORDER BY created_at`, [epStart])

// 审计(denied/写入)
const audit = q(`SELECT actor,action,target_id AS target,at FROM audit_log WHERE at >= ? ORDER BY at`, [epStart])

// 任务链(根任务状态/收口者)
const taskRow = line0?.taskId ? q(`SELECT id,state,assignee_id FROM tasks WHERE id=?`, [line0.taskId])[0] : null

// dispatch 后 PV 响应:quality.jsonl 中 part-weight 曲线
const quality = existsSync(join(runDir, `${label}-quality.jsonl`))
  ? readFileSync(join(runDir, `${label}-quality.jsonl`), 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  : []
const pvRows = quality.filter(r => String(r.name ?? '').includes('part-weight'))

// ── 七环判定(对每个 agent 写事件)──
const chains = agentWrites.map((w) => {
  const rings = {
    task_context: Boolean(taskRow?.id) || Boolean(w.taskId),
    agent_toolcall: toolcalls.some(c => /recipe_trial|dcw_control|recipe_update/.test(c.name ?? '')),
    governance: true, // 台账行存在即经过写控咽喉(dcw-writes.json 只记治理写)
    approval: Boolean(w.approvalId) || autoApprovals.length > 0 || hitlCards.some(c => c.status !== 'pending'),
    driver_receipt: Boolean(w.ack),
    readback: w.ack === 'readback-verified',
    post_daq: pvRows.some(r => new Date(r.at).getTime() >= new Date(w.at).getTime()),
  }
  const missing = Object.entries(rings).filter(([, ok]) => !ok).map(([k]) => k)
  return { write: { at: w.at, node: w.nodeId, value: w.value, ack: w.ack, taskId: w.taskId ?? null, approvalId: w.approvalId ?? null }, rings, missing, verdict: missing.length === 0 ? 'chain_complete' : `chain_incomplete(${missing.join(',')})` }
})

// ── 失败分类学输入 ──
const denialCount = audit.filter(a => a.action === 'tool.call.denied').length
const taxonomy = {
  worker_toolcalls: toolcalls.map(c => `${c.name}(${String(c.args).slice(0, 80)})`),
  worker_texts: wsTexts.slice(-6),
  denials: denialCount,
  task_final_state: taskRow?.state ?? line0?.finalState ?? 'unknown',
  completed_without_band: Boolean(taskRow?.state === 'COMPLETED' && line0 && line0.inBand === false),
}

const verdict = chains.some(c => c.verdict === 'chain_complete')
  ? (agentWrites.length > 0 && toolcalls.length > 0 ? 'CHAIN_COMPLETE' : 'CHAIN_COMPLETE(script-side only)')
  : (epWrites.length > 0 ? 'PARTIAL(script writes only, no agent-attributed governed write)' : 'NO_WRITE')

const outDir = arg('out', join(runDir, 'chain-evidence'))
mkdirSync(outDir, { recursive: true })
const sha = (s) => createHash('sha256').update(s).digest('hex').slice(0, 16)
const result = {
  run: basename(runDir), label, awHome, collectedAt: new Date().toISOString(),
  window: { start: epStart, end: epEnd },
  independent: {
    finalState: line0?.finalState ?? null, pvFinal: line0?.pvFinal ?? null, pvTarget: line0?.pvTarget ?? null,
    inBand: line0?.inBand ?? null, guardsOk: line0?.guardsOk ?? null,
  },
  counts: { epWrites: epWrites.length, agentWrites: agentWrites.length, toolcalls: toolcalls.length, hitlCards: hitlCards.length, autoApprovals: autoApprovals.length, denials: denialCount },
  chains, taxonomy, hitlCards, autoApprovals,
  verdict,
}
writeFileSync(join(outDir, 'chain-evidence.json'), JSON.stringify(result, null, 2))
const md = [
  `# live-Agent 链式证据 · ${basename(runDir)}`,
  ``,
  `- 判定:**${verdict}**`,
  `- 独立终验: finalState=${result.independent.finalState} pv=${result.independent.pvFinal}(带${result.independent.inBand ? '内' : '外'}) guards=${result.independent.guardsOk ? 'OK' : 'VIOLATED'}`,
  `- 写台账: 线上写 ${epWrites.length} 条,其中 agent 关联(taskId/approvalId) ${agentWrites.length} 条`,
  `- worker 工具调用: ${toolcalls.length} 次; HITL 卡 ${hitlCards.length} 张(runner 代批 ${autoApprovals.length}); 拒绝审计 ${denialCount}`,
  ``,
  ...chains.map(c => `- ${c.verdict === 'chain_complete' ? '✔' : '✘'} ${c.write.at} node=${c.write.node} v=${c.write.value} ack=${c.write.ack} → ${c.verdict}`),
  ``,
  `- 收口纪律: task=${taxonomy.task_final_state}${taxonomy.completed_without_band ? '(**带外收口 = G-1 判据旁路实证**)' : ''}`,
].join('\n')
writeFileSync(join(outDir, 'chain-evidence.md'), md)
console.log(md)
console.log(`\n→ ${outDir}`)
process.exit(0)
