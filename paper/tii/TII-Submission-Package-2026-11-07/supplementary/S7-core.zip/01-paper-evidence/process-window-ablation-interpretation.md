# Interpretation note: process-window ablation

The archived `process-window-ablation-report.md` labels six HTTP 200 window-violation responses as executed and journaled. The archived `validation-summary.json` gives the same cases the derived label `processWindowDriverReach`.

The archive contains the request rows and HTTP statuses in `process-window-ablation.csv`, but it has no independent per-request driver-call or journal ledger and no response bodies. These runner labels therefore do not independently verify that a request reached the mock driver. The paper reports the observed HTTP responses and does not count them as verified driver arrivals.

The report also refers to `e1-lite.csv`, which is absent from this archive; the corresponding raw rows are in `process-window-ablation.csv`. The original report, summary, and CSV are preserved unchanged. This note clarifies their interpretation only.
