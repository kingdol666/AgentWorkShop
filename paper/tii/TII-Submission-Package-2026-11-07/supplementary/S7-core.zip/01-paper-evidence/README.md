# Supplementary File S7 evidence archive

This archive contains the source records cited in the revised paper's evaluation. Each run block retains its own denominator; the files are not pooled into one pass rate.

- Integrated pipeline: runs 20261101103641-9j8 and 20261101104849-xu0.
- Scene/protocol probes: valid run 20261101121221-scenario-probes (four scenes; five protocol families across the set).
- Optimization: five matched seeds (42--46), three simulator scenes, separate C0 and C1 CSVs named by source run ID.
- Process-window ablation: run 20261101103356-e1lite.
  Read `process-window-ablation-interpretation.md` before interpreting runner execution labels.
- Approval pilot: run 20261101121436-approval-gate.
- Production-mode guard checks: run 20261101113644-production-guards.
- Authorization checks: run 20261101121415-authorization.

A later cast-film probe run was excluded because its recorded simulator endpoint disagreed with its reproduction command and it executed only one of the four declared scenes. Its values do not appear in the paper or this archive. The integrated manifests show an already-running platform/simulator and no active Agent harness. No file represents a physical-plant test.

Open `latest-experiment-report.html` for the self-contained visual summary. `validation-summary.json` contains machine-readable endpoint, protocol-node, duration, and workload summaries; `file-manifest.json` records SHA-256 values for the other files in this archive. Reproduction commands and evidence limits are described in Supplementary File S7.
