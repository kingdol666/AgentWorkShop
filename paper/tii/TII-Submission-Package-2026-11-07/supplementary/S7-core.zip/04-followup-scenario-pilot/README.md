# Follow-up exploratory scenario pilot

- Run plan: `pexp-mw0dmt4v-na04`
- Recorded at: `2026-11-03T07:43:08.300Z`
- Line: `ln-00e0726d`
- Scope: one injection-molding scenario on an isolated platform with a PLC-based simulated twin (`realPlant=false`); no active Agent and no physical plant.
- Outcome: three DoE interventions (one identifiable contrast), one subsequent governed setpoint write to 63.7 bar with matching device readback, and a 32.224 g process observation within the 32.00--32.30 g band.
- The reported 15/15 are acceptance-script assertions over this single execution, not independent trials. The gain estimate of 0.05035 g/bar uses one identifiable sample.
- Provenance is less complete than the frozen November 1 evidence: this run record does not contain a platform commit, simulator snapshot/configuration hash, or runner-source hash. The acceptance report gives broad v0.9.4/v0.9.5 context only; it does not identify a hermetic source snapshot.

Files:
- `REPORT.md`: v0.9.5 multi-scene acceptance report and scenario context.
- `real-scenario-optimization.json`: machine-readable run result.
- `real-scenario-optimization.log`: execution trace.
