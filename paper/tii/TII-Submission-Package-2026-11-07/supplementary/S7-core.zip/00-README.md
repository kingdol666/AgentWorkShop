# Supplementary File S7 Data — Consolidated Package (2026-11-04)

This package contains the frozen November 1 experiment batch, the separate November 2 negative live-Agent pilot, prior system-validation material, and a separately documented November 3 exploratory injection-twin scenario pilot. Results use distinct fixtures, units, and denominators and are not pooled.

## 01-paper-evidence/

The frozen November 1 batch used for the six main evaluation blocks. It contains the integrated pipeline runs, scene--protocol probes, five-seed policy comparison, guard ablation, approval/authorization records, production-mode guard checks, figure, self-contained report, validation summary, and manifest. The manuscript retains each block's original unit and denominator.

## 02-c3-pilot-negative/

A November 2 live-Agent multi-round pilot. It is reported only as a negative result: the two recorded episodes issued zero governed writes; one task was marked `COMPLETED` with the process variable outside the target band, and the other timed out.

## 03-system-validation-not-used/

Earlier integration/regression and live-demo reports. They validate software paths but are not pooled with the manuscript's controlled experimental outcomes.

## 04-followup-scenario-pilot/

One November 3 exploratory injection-molding scenario on an isolated platform and PLC-based simulated twin (`realPlant=false`). The acceptance script ran three DOE interventions, of which one was classified as identifiable, followed by one governed setpoint write with matching readback and one in-band process observation. Its 15/15 count is the number of script assertions over this single execution, not 15 independent runs. The gain estimate is based on one identifiable sample. This pilot is separate from the frozen six-block study and does not establish active-Agent performance or physical-plant behavior.

The follow-up run record has less complete provenance than the frozen batch: it lacks a platform commit, simulator snapshot/configuration hash, and runner-source hash. The acceptance report provides broad v0.9.4/v0.9.5 context only and does not establish a hermetic source snapshot.

## Provenance notes

- Main paper-evidence batch: platform commit `da627d21`, isolated service/simulator ports 3005/4011, seeds 42--46, with a separate production-mode instance on port 3010. Experiment runners were uncommitted at execution time.
- Negative live-Agent pilot: working tree on top of `40533741` plus uncommitted pipeline fixes; isolated benchmark instance, injection scene.
- Follow-up scenario pilot: run plan `pexp-mw0dmt4v-na04`, recorded `2026-11-03T07:43:08.300Z`, line `ln-00e0726d`; run record lacks a commit and source/configuration hashes.
- No physical-plant data are included.

`manifest.json` lists checksums for all included evidence files, except the manifest itself. `04-followup-scenario-pilot/SHA256SUMS.txt` also records checksums for the five follow-up files as a local audit convenience. The enclosing submission manifest records the final archive checksum.
