# Interpretation erratum for the preserved E6/E7 records

This note corrects aggregation and interpretation only. Raw run files, including the runner-generated reports, are preserved unchanged.

## E6: valid paired denominator

The frozen schedule listed 12 blocks. Block 1 (injection, seed 43) was run and retained as the pilot in `E6/pilot/`; it is not part of the confirmation denominator. The post-pilot run contains blocks 2–12, or **11 confirmation attempts**. A pair is valid only when both C0 and C1 arms have `valid=true` in the block-level run record. The C0 sampling-gap flags invalidate block 8 (wastewater, seed 45; 9-s gap at 150.248 s) and block 12 (annealing, seed 46; 6-s gap at 11.534 s). Thus **9 of 11 confirmation pairs are valid**. Neither invalid pair is replaced or included in a median; the separate pilot is not pooled.

The valid-pair differences are recomputed as ΔIAE = IAE(C0) − IAE(C1). Positive values indicate lower IAE in the scripted C1 arm for that tested pair; they are not evidence of statistical significance or general superiority.

| Scene | Valid pairs | Valid seeds | Median ΔIAE (C0 − C1) | Valid-pair range |
|---|---:|---|---:|---:|
| Injection | 3/3 | 44, 45, 46 | 165.165 g·s | 162.535–195.169 g·s |
| Wastewater | 3/4 | 43, 44, 46 | 615.605 (mg/L)·s | 611.670–630.980 (mg/L)·s |
| Annealing | 3/4 | 43, 44, 45 | 8000.450 HV·s | 7930.200–8084.150 HV·s |

The separate pilot block 1 has ΔIAE = 163.240 g·s. It is not included in the values above. The C1 mission records marked `attained=true` are not a substitute for the paired validity rule or for recomputing an endpoint from raw samples.

The preserved `E6/confirmation/report.md` and the `perScene` convenience aggregate in `run.json` include IAE differences from the two invalid pairs. The `paired-summary.csv` also retains their calculated differences, but marks the corresponding rows `valid=false`. Do not use the report's `4/4` wastewater/annealing counts, the `perScene` pair totals, or `9/12` as the valid confirmation denominator. Use the block-level C0 and C1 validity flags and the valid seed sets above. The raw files are unchanged so that this correction remains auditable.

The comparison is a small, pre-registered exploratory simulator comparison of a deterministic scripted C1 path against a no-write C0 path. It is not an LLM-agent comparison, a PID comparison, a powered statistical test, or a physical-plant experiment. Horizons were 180 s for injection and 240 s for wastewater and annealing; sampling was nominally 1 s, arm order was randomized within blocks, and each arm used an independent reset with setpoint verification and a pre-specified initial-process-value window.

## E7: recorder-reported episode outcomes

The three saved episodes have process values 31.70, 31.87, and 31.99 g against the 32.15–32.85 g target band. All three ended `CANCELED`; none was in band. The run record/episode recorder reports two writes and two rounds for each episode. Elapsed times were 380.10, 372.36, and 372.23 s. The configured 20 min is an episode budget cap, not elapsed runtime and not a budget-exhaustion result. Guard flags in the saved metadata are `false`, `true`, and `true`.

A server-side append-only journal export is not present in these saved episode folders. Therefore, this archive supports the statement that the episode recorder logged two writes per episode; it does not independently corroborate six `src=agent` journal events. The outcomes remain a three-episode simulator pilot and do not demonstrate task success, autonomous control quality, or physical-device operation.
