# E6/E7 supplementary evidence archive (2026-11-07)

This archive preserves the planned E6 schedule, the separately run E6 pilot, the post-pilot E6 confirmation attempts, and the latest three-episode E7 simulator pilot. It includes the original run files without editing their contents. `INTERPRETATION-ERRATUM.md` gives the validity-based E6 aggregation and the recording limits for E7. `SHA256SUMS.txt` lists SHA-256 checksums for all other archive members.

The archive contains experimental outputs, not a self-contained runtime or an experiment-reproduction environment. The runs used services already running on the local benchmark host; the full platform, simulator, and exact active source tree were not frozen here. E6 run metadata records commit `e5398281` and harness hash `b0b826cd0b7e48c9353361ad23fe39b4f81e02e43f0ac27eb94185ded41f96a9`. E7 metadata does not include an equivalent complete runtime-source snapshot. Do not interpret this archive as evidence of physical-plant operation.

## Contents

- `E6/plan/`: frozen scenario schedule and arm-order list.
- `E6/pilot/`: block 1 (injection, seed 43), kept separate from the post-pilot confirmation attempts.
- `E6/confirmation/`: original blocks 2–12, including raw arm samples, metrics, reset records, `run.json`, `paired-summary.csv`, and the runner-generated `report.md`. The latter's aggregate validity counts are superseded by the erratum; the original file is retained for provenance.
- `E7/agent-multiround/`: three-episode recorder output and run metadata.
- `E7/optloop/episode-1` through `episode-3/`: corresponding process timelines, setpoint/quality samples, worker streams, and summaries.
