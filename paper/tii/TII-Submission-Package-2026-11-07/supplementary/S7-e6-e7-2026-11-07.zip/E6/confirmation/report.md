# E6 固定时域配对对照(CONFIRMATORY-EXPLORATORY (n=12 pairs, no significance claims))

- run: `202611062020-e6-paired` · base http://127.0.0.1:3577 · plan sha256 e9ba4b47ccc07fcf… · git e5398281
- 协议: 每 scene×seed 两臂独立 fresh 复位(逐 SP 核对+初值 PV 预注册窗),臂序块内随机化(orderSeed=20261107);
  共同 horizon T=injection:180s/wwtp:240s/anneal:240s · 采样 1s · 主指标 IAE(梯形法)。
- C1 = 论文同一策略代码路径(recipe_trial 受治理写),E6_DEADLINE_MS 于 T−settle−3s 停新轮;C0 全程无写。

| scene | 有效对 | ΔIAE 中位(C0−C1,>0=策略降误差) | 各 seed ΔIAE |
|---|---|---|---|
| injection | 3/4 | 165.165 | seed44:165.165 · seed45:162.535 · seed46:195.169 |
| wwtp | 4/4 | 615.605 | seed43:615.605 · seed44:611.67 · seed45:583.29 · seed46:630.98 |
| anneal | 4/4 | 8084.15 | seed43:7930.2 · seed44:8000.45 · seed45:8084.15 · seed46:8487.054 |

## 口径(预注册,不得事后放宽)

1. **探索性**:n≤12 对/比较,不做显著性/优越性声明;仅报告配对差值方向与中位。
2. INVALID(复位核对失败/初值出窗/采样缺口>5s/覆盖不足)如实保留,不补跑、不按方向筛选。
3. C1 的写入经 recipe_trial 受治理路径(配方窗+绑定收窄+节拍),写入被治理拒绝计 rounds−writes。
4. 初值窗:injection [30.75, 31.75] · wwtp [-0.1, 0.6] · anneal [131.7, 137.7]。

## block 2: wwtp seed43(臂序 C0→C1)

- C0: IAE=763.17 在带=0 超限=2.73 首次入带=删失s writes=0/0 attained=null
- C1: IAE=147.565 在带=0.688 超限=2.45 首次入带=77.945s writes=11/12 attained=true
- 配对 ΔIAE(C0−C1) = 615.605

## block 3: anneal seed43(臂序 C1→C0)

- C0: IAE=9497.35 在带=0 超限=35.3 首次入带=删失s writes=0/0 attained=null
- C1: IAE=1567.15 在带=0.813 超限=33.8 首次入带=45.617s writes=8/9 attained=true
- 配对 ΔIAE(C0−C1) = 7930.2

## block 4: injection seed44(臂序 C1→C0)

- C0: IAE=224.05 在带=0 超限=1.02 首次入带=删失s writes=0/0 attained=null
- C1: IAE=58.885 在带=0.694 超限=0.28 首次入带=7.8759999999999994s writes=2/3 attained=true
- 配对 ΔIAE(C0−C1) = 165.165

## block 5: wwtp seed44(臂序 C0→C1)

- C0: IAE=759.34 在带=0 超限=2.7 首次入带=删失s writes=0/0 attained=null
- C1: IAE=147.67 在带=0.767 超限=2.487 首次入带=56.493s writes=11/12 attained=true
- 配对 ΔIAE(C0−C1) = 611.67

## block 6: anneal seed44(臂序 C1→C0)

- C0: IAE=9481.9 在带=0 超限=35.8 首次入带=删失s writes=0/0 attained=null
- C1: IAE=1481.45 在带=0.796 超限=34.4 首次入带=49.04s writes=9/11 attained=true
- 配对 ΔIAE(C0−C1) = 8000.45

## block 7: injection seed45(臂序 C1→C0)

- C0: IAE=223.015 在带=0 超限=0.99 首次入带=删失s writes=0/0 attained=null
- C1: IAE=60.48 在带=0.667 超限=0.25 首次入带=9.932s writes=2/3 attained=true
- 配对 ΔIAE(C0−C1) = 162.535

## block 8: wwtp seed45(臂序 C0→C1)

- C0: INVALID(采样缺口 9s @150.248s)
- C1: IAE=179.725 在带=0.704 超限=2.51 首次入带=66s writes=12/12 attained=true
- 配对 ΔIAE(C0−C1) = 583.29

## block 9: anneal seed45(臂序 C1→C0)

- C0: IAE=9488.15 在带=0 超限=35.6 首次入带=删失s writes=0/0 attained=null
- C1: IAE=1404 在带=0.804 超限=32.1 首次入带=50.948s writes=9/11 attained=true
- 配对 ΔIAE(C0−C1) = 8084.15

## block 10: injection seed46(臂序 C0→C1)

- C0: IAE=223.585 在带=0 超限=1.03 首次入带=删失s writes=0/0 attained=null
- C1: IAE=28.416 在带=0.939 超限=0.31 首次入带=14.447s writes=3/4 attained=true
- 配对 ΔIAE(C0−C1) = 195.169

## block 11: wwtp seed46(臂序 C1→C0)

- C0: IAE=764.141 在带=0 超限=2.74 首次入带=删失s writes=0/0 attained=null
- C1: IAE=133.161 在带=0.763 超限=2.485 首次入带=58s writes=10/11 attained=true
- 配对 ΔIAE(C0−C1) = 630.98

## block 12: anneal seed46(臂序 C1→C0)

- C0: INVALID(采样缺口 6s @11.534s)
- C1: IAE=1017.338 在带=0.892 超限=33.665 首次入带=26.412s writes=6/7 attained=true
- 配对 ΔIAE(C0−C1) = 8487.054
