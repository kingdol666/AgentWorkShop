# E6 固定时域配对对照(PILOT)

- run: `202611061959-e6-paired` · base http://127.0.0.1:3577 · plan sha256 e9ba4b47ccc07fcf… · git e5398281
- 协议: 每 scene×seed 两臂独立 fresh 复位(逐 SP 核对+初值 PV 预注册窗),臂序块内随机化(orderSeed=20261107);
  共同 horizon T=injection:180s/wwtp:240s/anneal:240s · 采样 1s · 主指标 IAE(梯形法)。
- C1 = 论文同一策略代码路径(recipe_trial 受治理写),E6_DEADLINE_MS 于 T−settle−3s 停新轮;C0 全程无写。

| scene | 有效对 | ΔIAE 中位(C0−C1,>0=策略降误差) | 各 seed ΔIAE |
|---|---|---|---|
| injection | 1/4 | 163.24 | seed43:163.24 |
| wwtp | 0/4 | — | — |
| anneal | 0/4 | — | — |

## 口径(预注册,不得事后放宽)

1. **探索性**:n≤12 对/比较,不做显著性/优越性声明;仅报告配对差值方向与中位。
2. INVALID(复位核对失败/初值出窗/采样缺口>5s/覆盖不足)如实保留,不补跑、不按方向筛选。
3. C1 的写入经 recipe_trial 受治理路径(配方窗+绑定收窄+节拍),写入被治理拒绝计 rounds−writes。
4. 初值窗:injection [30.75, 31.75] · wwtp [-0.1, 0.6] · anneal [131.7, 137.7]。

## block 1: injection seed43(臂序 C1→C0)

- C0: IAE=223.985 在带=0 超限=1.02 首次入带=删失s writes=0/0 attained=null
- C1: IAE=60.745 在带=0.633 超限=0.27 首次入带=33.132s writes=2/3 attained=true
- 配对 ΔIAE(C0−C1) = 163.24
