# IEEE TII 论文配图：设计、源文件与使用说明

这套图依照当前论文、平台实现及冻结实验记录设计。论文当前使用 `resources/redesigned-*.pdf`；此目录保存可以二次开发的源代码和绘图文件。

## 文件与设计决策

| 图 | 信息与改进 | 出版矢量图 | 可编辑图 |
|---|---|---|---|
| 1 | 区分同一 MQTT 协议下的线速控制与膜厚测量，以及命令证据和后续过程观测；单位核对模拟器 preset。 | `fig12/fig1_cast_film.pdf` | `fig12/fig1_cast_film.drawio` |
| 2 | 显示任务入口和直接入口、共享分发、读写服务、方向映射与独立记录；虚线表示配置关联。 | `fig12/fig2_runtime_architecture.pdf` | `fig12/fig2_runtime_architecture.drawio` |
| 3 | 把条件审批、可选预检、命令回执、过程观察和 Agent 后续决策分开；是概念流程，并非成功的真实 Agent 试验。 | `fig34/fig3_task_to_write.pdf` | `fig34/fig3_task_to_write.drawio` |
| 4 | 并列展示三类限值，分别说明单节点和配方路径，以及适用的复核和共享控制。 | `fig34/fig4_route_governance.pdf` | `fig34/fig4_route_governance.drawio` |
| 5 | 展示 30 个原始终点和 24 个消融状态；保留不匹配观测时间、seed 42 残留状态和 HTTP 状态限制。 | `fig5/fig5-reproducible.pdf` | `fig5/fig5-editable.drawio` |

每张图同时有 SVG 与 PNG；PDF 用于论文，PNG 用于预览。所有 PDF 为矢量图，字体嵌入。蓝绿与琥珀的区分也使用文字、线型或标记形状，不仅依靠颜色。绘制方案根据 IEEE Author Center 的尺寸、字体、图形和无障碍建议设计；请以投稿时 TII 投稿系统的要求为准。

## draw.io 和 XMind

在 diagrams.net / draw.io 中使用“文件 → 从设备打开”选择 `.drawio`；节点、标签、连线或数据点为独立对象。文件已做 XML 和对象结构检查；本机未提供 draw.io 桌面程序，尚未实际在图形界面中进行打开、编辑与再导出的测试。编辑后应重新核对图注与导出效果。

`fig1-xmind.opml` 至 `fig5-xmind.opml` 为每张图的可编辑内容结构，选择 XMind“文件 → 导入 → OPML”导入。它们是内容大纲，不会恢复论文图的二维版式或全部数据标记；需保留原图布局时使用 `.drawio`。这不是原生 `.xmind` 文件。

图 5 的 draw.io 版使用浅色目标区，而论文 PDF 使用斜纹目标区；如果把 draw.io 版直接导出到论文，必须同步调整图注。修改数据请使用 CSV 和脚本重生成，不要只拖动数据点。

## 重新生成

- 图 1–2：`python fig12/build_figures.py`
- 图 3–4：`python fig34/generate.py`
- 图 5：`python fig5/render_figure5.py` 然后 `python fig5/make_editable_drawio.py`。图 5 主程序读取上级论文目录的 `Supplementary-File-S7-data-2026-11-04.zip`；图表数据及消融计数有断言。详见 `fig5/README.md`。

需要 Python、Matplotlib、Times New Roman 等字体。脚本可再生图，但不会自动替换正文 `resources` 内的 PDF；确认图后复制相应 PDF 并重新编译 LaTeX。

## 核查边界

所有结果图都来自模拟器与模拟驱动，不能证明实体产线安全或控制效果；HTTP 200 不独立证明驱动调用。图 5 脚本式策略与无写入组采用不同时间尺度及终点定义，不应据图推断因果效益。字体、构建与视觉检查不等于 TII 接收保证。作者应复核示意例子与实际投稿版本、权限及最终期刊要求。
