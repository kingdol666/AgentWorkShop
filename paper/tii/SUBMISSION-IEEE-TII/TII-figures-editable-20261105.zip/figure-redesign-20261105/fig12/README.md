# Figure 1–2: editable vector designs

- `fig1_cast_film.*`: illustrative cast-film context and direction-specific signal/evidence separation. It does not assert that the commanded speed caused the later thickness measurement.
- `fig2_runtime_architecture.*`: architectural overview; functional groups do not imply that all read/analysis services invoke a field driver. The plant is an architectural endpoint, not a claim of physical-plant testing. A configured MES-REST adapter may implement a control mapping.
- `.drawio` contains independent editable native vertices and connectors in uncompressed mxGraph XML; `.svg` contains editable text; `.pdf` embeds Times New Roman; `.png` is a 300-dpi preview.
- Rebuild with `python build_figures.py`; Python requires Matplotlib and Times New Roman. Rebuilding overwrites diagrams; edits made in diagrams.net are not incorporated into the Python script automatically.
- XML structure was parsed and checked. GUI import/export was not verified in this environment; confirm using diagrams.net before submission.
- Canvas size: Figure 1 252×143 pt and Figure 2 504×251 pt; font 9.5–10 pt at those sizes. Check actual font size after scaling to the final column width and check captions against final manuscript.

