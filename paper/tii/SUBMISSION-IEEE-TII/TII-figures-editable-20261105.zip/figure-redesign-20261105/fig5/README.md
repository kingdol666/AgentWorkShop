# Figure 5: simulator endpoints and guard-ablation responses

## Outputs

- `fig5-reproducible.pdf`: vector figure for the paper; 7.16 in wide; Times New Roman fonts embedded; extracted font size 9 pt at source width. The current main-paper text width is approximately 7.14 in, giving approximately 8.97 pt after scaling. Confirm at the final submission size.
- `fig5-reproducible.svg`: editable vector artwork (text remains text). `fig5-reproducible.png` is a 300-dpi preview.
- `fig5-editable.drawio`: native diagrams.net objects, including separate labels, axes, target bands, 30 markers and 24 ablation status marks. Select and edit elements in diagrams.net via File > Open From > Device. This version uses a solid light target band, rather than the PDF's hatched band; it is an editable reconstruction and is not a linked chart. When using it in a manuscript, export to PDF and update the caption accordingly.
- `endpoints.csv` and `window_ablation.csv`: the plotted source values and HTTP statuses. Retain units and target/tolerance fields when editing.
- `render_figure5.py`: recreates the publication PDF, SVG, PNG and the two CSV files directly from the frozen S7 archive at `../../Supplementary-File-S7-data-2026-11-04.zip` relative to this folder. `make_editable_drawio.py` generates the native editable version from those CSVs.

## Reproduce

Run `python render_figure5.py`, followed by `python make_editable_drawio.py` from any directory. Python, Matplotlib and the frozen archive are required. The scripts assert 30 unique endpoints, the 0/15 and 15/15 endpoint band counts, and ablation HTTP-200 counts 0/6, 6/6, 0/6, 6/6. Editing CSV alone does not update the PDF; the PDF generator re-extracts the frozen records.

## Interpretation

The two endpoint conditions use different horizons and endpoint definitions; the comparison does not isolate a control-policy effect. Two no-write seed-42 runs began from residual states. The lower matrix shows responses for deterministic technical repetitions, not independent trials. HTTP 200 alone does not prove driver invocation. The removed-readback arm contains no injected readback mismatch.

## Figure audit

Vector output and individual source data: pass. Colour plus marker shape distinguishes series in grayscale: pass. Axes include physical units and target ranges: pass. All 30 endpoints are shown directly, so error bars are not used. Caption remains essential for the unequal durations, seed-42 detail, sample definitions and ablation protocol. This inspection does not establish experimental efficacy or journal acceptance.
