# 论文证据轮汇总

- 汇整时间: 2026-11-05T06:26:55.556Z

| Run 目录 | 类型 | 判定 | 关键分母 |
|---|---|---|---|
| 20261105-agent-qualify | agent-qualify | QUALIFIED | Q1-platform=ok Q2-simulator=ok Q3-omp-cli=ok Q4-model-endpoint=ok Q5a-auth=ok Q5-provision=ok Q6-governed-write=ok |
| 20261105060237-scenario-probes | scenario-probes | PASS | legal=220/220 structural=219/219 window=110/110 readback=216/216 windowFrac=0.8 |
| 20261105060514-readback-mismatch | readback-mismatch | PASS | downgraded=true mismatchVisible=true node=dw-ce8da5f5 |
| 20261105060550-agent-multiround | run | UNKNOWN |  |

- 总判定: **存在 FAIL/未达标(逐行见上)**
- 产物校验: SHA256SUMS.txt(11 文件)
