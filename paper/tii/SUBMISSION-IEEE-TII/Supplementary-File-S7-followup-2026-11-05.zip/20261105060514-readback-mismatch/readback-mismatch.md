# E5 回读不匹配注入探针

- run: `20261105060514-readback-mismatch`(git 3f30a146, base http://127.0.0.1:3577, sim http://127.0.0.1:4012)
- 节点: dw-ce8da5f5(scen-injection:dcw:barrel-temp-1-sp) span=140 容差=0.7 注入 offset=+21
- 模拟器: already-up · 平台: already-up

| 步骤 | 写值 | 状态 | ack | 驱动回读 | 独立回读 | 独立偏差 |
|---|---|---|---|---|---|---|
| baseline | 209 | 200/true | readback-verified | 209 | 209 | 0 |
| faulted | 230 | 200/false | unverified | 251 | 251 | 0 |
| recovery | 251 | 200/true | readback-verified | 251 | 251 | 0 |

## 判定口径

1. baseline 必须为 readback-verified(夹具自检;不达标=夹具不可用,不是机制结论)。
2. faulted 要求两点同时成立:ack 降级(≠ readback-verified,含 failed/unverified/transport-ack)且独立回读偏差 > 容差。
3. recovery 必须恢复 readback-verified(排除「故障把节点写坏」的替代解释)。

**判定:PASS** — 回读不匹配使回执如实降级,恢复后回读证实;写路径未把链路受理伪装成设备证实。
